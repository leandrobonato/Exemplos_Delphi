DDevExtensions
==============

(C) 2006-2020 Andreas Hausladen
Andreas.Hausladen@gmx.de
http://andy.jgknet.de/ddev

DDevExtensions adds new features to RAD Studio.


=== How to install ===

Simply start the DDevExtensionsReg.exe.

This will copy files to $(APPDATA)\DDevExtensions and it registers the expert DLLs
in the registry.


=== How to uninstall ===

Start the InstallDDevExtensions.exe and press the <Uninstall> button.

